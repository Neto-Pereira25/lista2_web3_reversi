import { ReversiServer } from "./websocket/WebSocketServer.js";

new ReversiServer(3000);
